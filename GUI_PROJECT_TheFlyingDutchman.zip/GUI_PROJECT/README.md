# GUI_PROJECT
Group project for the course User Interface Programming I

We provide the implementation of a pub ordering system which fulfills four requirements: internationalization, drag and drop, undo-redo and responsive web design. There are two languages for this system, English and Swedish. Before user logs in, they can scan the whole menu. After logging in, user could click on the blocks to put products into the bill list. The bill list will show up in the right side.  

There are 4 folders and 1 html files in this project. "js" folder store all the javascript files for this website. 